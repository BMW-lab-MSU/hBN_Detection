# MonArk_BN_Modified_Classes > 2022-06-09 9:43am
https://universe.roboflow.com/object-detection/monark_bn_modified_classes

Provided by Roboflow
License: CC BY 4.0

