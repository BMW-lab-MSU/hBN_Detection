# UA_BN_Dataset > 2022-08-03 4:03pm
https://universe.roboflow.com/object-detection/ua_bn_dataset

Provided by Roboflow
License: CC BY 4.0

