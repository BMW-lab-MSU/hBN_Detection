# Masubuchi_Object_Detection > 2022-08-03 4:01pm
https://universe.roboflow.com/object-detection/masubuchi_object_detection

Provided by Roboflow
License: CC BY 4.0

